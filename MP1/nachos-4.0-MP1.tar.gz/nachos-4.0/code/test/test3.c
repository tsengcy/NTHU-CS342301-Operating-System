#include "syscall.h"
// #include "iostream.h"

main()
{
	char* filename = "./file.txt";
	Create(filename);
	int id = Open(filename);
	PrintInt(id);

	
	Write(filename, 10, id);
	Close(id);
	
	int id2 = Open(filename);
	char buffer[6];
	Read(buffer, 5, id2);
	PrintMsg(buffer);
	

	char* filename2 = "./file2.txt";
	int id3 = Open(filename2);
	PrintInt(id3);

	Close(id2);
	Close(id3);
	Write(filename, 10, id+1);
}
